async function getWeather() {

    let city = document.getElementById("city").value;

    let apiKey = "";

    let url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    try {

        let response = await fetch(url);

        let data = await response.json();

        document.getElementById("result").innerHTML = `
            <h3>${data.name}</h3>
            <p>Temperature: ${data.main.temp} °C</p>
            <p>Weather: ${data.weather[0].description}</p>
            <p>Humidity: ${data.main.humidity}%</p>
        `;

    } catch (error) {

        document.getElementById("result").innerHTML =
            "Error fetching weather data";

    }
}